/*     CalculiX - A 3-dimensional finite element program                   */
/*              Copyright (C) 1998-2018 Guido Dhondt                          */

/*     This program is free software; you can redistribute it and/or     */
/*     modify it under the terms of the GNU General Public License as    */
/*     published by the Free Software Foundation(version 2);    */
/*                    */

/*     This program is distributed in the hope that it will be useful,   */
/*     but WITHOUT ANY WARRANTY; without even the implied warranty of    */
/*     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the      */
/*     GNU General Public License for more details.                      */

/*     You should have received a copy of the GNU General Public License */
/*     along with this program; if not, write to the Free Software       */
/*     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.         */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "CalFSI.h"
#include <string.h>

#include "PreciceInterface.h"

#include <math.h>
#ifdef SPOOLES
   #include "spooles.h"
#endif
#ifdef SGI
   #include "sgi.h"
#endif
#ifdef TAUCS
   #include "tau.h"
#endif
#ifdef PARDISO
   #include "pardiso.h"
   char envMKL[32];

#endif

void updateCO(double *coUpdated, double *v, int nk, int mt)
{	
	int i, a, b;
	int num_cpus=0;
	char *env;

	// get num of threads declaration, if any
	env = getenv("OMP_NUM_THREADS");
    if(num_cpus==0){
    	if (env)
      		num_cpus = atoi(env);
    	if (num_cpus < 1) {
      		num_cpus=1;
    	}
    }

	#pragma omp parallel for num_threads(num_cpus) private(a,b)
	for(i = 0; i<= nk-1; i++)
	{
		a = 3*i;
		b = a + i + 1;
		coUpdated[a]+=v[b];
		coUpdated[a+1]+=v[b+1];
		coUpdated[a+2]+=v[b+2];
	}
}

void linstatic_MDO(double *co, ITG *nk, ITG **konp, ITG **ipkonp, char **lakonp,
	     ITG *ne,
	     ITG *nodeboun, ITG *ndirboun, double *xboun, ITG *nboun,
	     ITG *ipompc, ITG *nodempc, double *coefmpc, char *labmpc,
             ITG *nmpc,
	     ITG *nodeforc, ITG *ndirforc,double *xforc, ITG *nforc,
	     ITG *nelemload, char *sideload, double *xload,
	     ITG *nload, ITG *nactdof,
	     ITG **icolp, ITG *jq, ITG **irowp, ITG *neq, ITG *nzl,
	     ITG *nmethod, ITG *ikmpc, ITG *ilmpc, ITG *ikboun,
	     ITG *ilboun,
	     double *elcon, ITG *nelcon, double *rhcon, ITG *nrhcon,
	     double *alcon, ITG *nalcon, double *alzero, ITG **ielmatp,
	     ITG **ielorienp, ITG *norien, double *orab, ITG *ntmat_,
	     double *t0, double *t1, double *t1old,
	     ITG *ithermal,double *prestr, ITG *iprestr,
	     double *vold,ITG *iperturb, double *sti, ITG *nzs,
	     ITG *kode, char *filab, double *eme,
             ITG *iexpl, double *plicon, ITG *nplicon, double *plkcon,
             ITG *nplkcon,
             double **xstatep, ITG *npmat_, char *matname, ITG *isolver,
             ITG *mi, ITG *ncmat_, ITG *nstate_, double *cs, ITG *mcs,
             ITG *nkon, double **enerp, double *xbounold,
	     double *xforcold, double *xloadold,
             char *amname, double *amta, ITG *namta,
	     ITG *nam, ITG *iamforc, ITG *iamload,
             ITG *iamt1, ITG *iamboun, double *ttime, char *output,
             char *set, ITG *nset, ITG *istartset,
             ITG *iendset, ITG *ialset, ITG *nprint, char *prlab,
             char *prset, ITG *nener, double *trab,
             ITG *inotr, ITG *ntrans, double *fmpc, char *cbody, ITG *ibody,
	     double *xbody, ITG *nbody, double *xbodyold, double *timepar,
	     double *thicke, char *jobnamec,char *tieset,ITG *ntie,
	     ITG *istep,ITG *nmat,ITG *ielprop,double *prop,char *typeboun,
	     ITG *mortar,ITG *mpcinfo,double *tietol,ITG *ics,ITG *icontact,
             char *orname,double *design, double *penal, double *stx, double *sigma0, double *eps,
			double *rhomin, double *pexp, double *Pnorm, double *dPnorm_drho, double *mat_dens, char *preciceParticipantName, char *configFilename, ITG *ikforc, ITG *ilforc)
	{

  		char description[13]="            ",*lakon=NULL,stiffmatrix[132]="",
       	fneig[132]="",jobnamef[396]="";

  		ITG *inum=NULL,k,*icol=NULL,*irow=NULL,ielas=0,icmd=0,iinc=1,nasym=0,i,j,ic,ir,
      	mass[2]={0,0}, stiffness=1, buckling=0, rhsi=1, intscheme=0,*ncocon=NULL,
      	*nshcon=NULL,mode=-1,noddiam=-1,*ipobody=NULL,inewton=0,coriolis=0,iout,
      	ifreebody,*itg=NULL,ntg=0,symmetryflag=0,inputformat=0,ngraph=1,im,
      	mt=mi[1]+1,ne0,*integerglob=NULL,iglob=0,*ipneigh=NULL,*neigh=NULL,
      	icfd=0,*inomat=NULL,*islavact=NULL,*islavnode=NULL,*nslavnode=NULL,
      	*islavsurf=NULL,nretain,*iretain=NULL,*noderetain=NULL,*ndirretain=NULL,
      	nmethodl,nintpoint,ifacecount,memmpc_,mpcfree,icascade,maxlenmpc,
      	ncont=0,*itietri=NULL,*koncont=NULL,nslavs=0,ismallsliding=0,
      	*itiefac=NULL,*imastnode=NULL,*nmastnode=NULL,*imastop=NULL,iitsta,
      	*iponoels=NULL,*inoels=NULL,*ipe=NULL,*ime=NULL,iit=-1,iflagact=0,
      	icutb=0,*kon=NULL,*ipkon=NULL,*ielmat=NULL,ialeatoric=0,kscale=1,
      	*iponoel=NULL,*inoel=NULL,zero=0,nherm=1,nev=*nforc,node,idir,
      	*ielorien=NULL,network=0,nrhs=1,iperturbsav;

  		double *stn=NULL,*v=NULL,*een=NULL,cam[5],*xstiff=NULL,*stiini=NULL,*tper,
        *f=NULL,*fn=NULL,qa[4],*fext=NULL,*epn=NULL,*xstateini=NULL,
        *vini=NULL,*enern=NULL,*xbounact=NULL,*xforcact=NULL,
        *xloadact=NULL,*t1act=NULL,*ampli=NULL,*xstaten=NULL,*eei=NULL,
        *enerini=NULL,*cocon=NULL,*shcon=NULL,*physcon=NULL,*qfx=NULL,
        *qfn=NULL,sigma=0.,*cgr=NULL,*xbodyact=NULL,*vr=NULL,*vi=NULL,
        *stnr=NULL,*stni=NULL,*vmax=NULL,*stnmax=NULL,*springarea=NULL,
        *eenmax=NULL,*fnr=NULL,*fni=NULL,*emn=NULL,*clearini=NULL,ptime,
        *emeini=NULL,*doubleglob=NULL,*au=NULL,*ad=NULL,*b=NULL,*aub=NULL,
        *adb=NULL,*pslavsurf=NULL,*pmastsurf=NULL,*cdn=NULL,*cdnr=NULL,
        *cdni=NULL,*submatrix=NULL,*xnoels=NULL,*cg=NULL,*straight=NULL,
        *areaslav=NULL,*xmastnor=NULL,theta=0.,*ener=NULL,*xstate=NULL,
        *fnext=NULL,*energyini=NULL,*energy=NULL,*d=NULL,alea=0.1, *brhs=NULL,
		*djdrho_expl = NULL, *djdrho_impl = NULL;

		double dtheta = 0.0;



		/* p-norm / stress aggregation parameters */
		//double sigma0 = 1.0;     /* allowable stress or scaling */
		//double eps   = 1e-3;    /* small relax epsilon */
		//double rhomin = 1e-3;    /* minimum density */
		//double pexp   = 8.0;     /* p-exponent for aggregation */

  		FILE *f1,*f2;

		#ifdef SGI
  		ITG token;
		#endif

        /* Create a new vector to store updated coordinates and copy initial coordinates */
	    double *coUpdated = NULL;
	    NNEW(coUpdated,double,3**nk);
	    memcpy(coUpdated, co, 3**nk*sizeof(double));
    


  		/* dummy arguments for the results call */

  		double *veold=NULL,*accold=NULL,bet,gam,dtime,time,reltime=1.;

  		irow=*irowp;
        ener=*enerp;
        xstate=*xstatep;
        ipkon=*ipkonp;
        lakon=*lakonp;
  		kon=*konp;
        ielmat=*ielmatp;
        ielorien=*ielorienp;
        icol=*icolp;

		
		long long blk = 27LL * mi[0];    /* number of doubles per element */
		int max_elems_to_show = 3;       /* print only first 3 elements */
		int max_vals_to_show  = 10;      /* print up to 10 nonzero values per element */
		

		/* temp adjoint flag*/
		int get_adjoint = 0;




  		for(k=0;k<3;k++)
  		{
    		strcpy1(&jobnamef[k*132],&jobnamec[k*132],132);
  		}

  		tper=&timepar[1];

  		time=*tper;
  		dtime=*tper;

  		ne0=*ne;


    /*---Asign values to CCX structure to hold coupling variables---*/
    struct SimulationData simulationData = 
    {
        .ialset = ialset,    				/*---Member of a set or surface. This is a node for node set, an element for element set---*/
        .ielmat = ielmat,					/*---Contains the material number for element i ---*/
        .istartset = istartset,				/*---Pointer to ialset containing the first set number---*/
        .iendset = iendset,					/*---Pointer to ialset containing the last set number---*/
        .kon = kon,							/*---Containts topology of all elements---*/
        .ipkon = ipkon,						/*---Points to the location in field kon preceding the topology of element i---*/
        .lakon = &lakon,					/*---Containts label for element i (C3D4, C3D8...)---*/
        .co = co,							/*---Node coordinates---*/
        .set = set,							/*---Name of the set: User defined name---*/
        .nset = *nset,						/*---Number of sets, including surfaces---*/
        .ikboun = ikboun,					/*---Containts all DOFs of the boundary conditions---*/
        .ikforc = ikforc,					/*---Ordered array of the DOFs corresponiding to the point loads---*/
        .ilboun = ilboun,					/*---Containts all the boundary conditions---*/
        .ilforc = ilforc,					/*---Original SPC number for ikforc(i)---*/
        .nboun = *nboun,   					/*---Total number of boundary conditions (Single Point Constraints)---*/	
        .nforc = *nforc,							/*---Number of point loads---*/
        .nelemload = nelemload,						/*---Element to which distributed load is applied----*/
        .nload = *nload,							/*---Number of facial distributed loads---*/
        .sideload = sideload,						/*---Load label; indicated element size to which load is applied---*/
        .mt = mt, 									/*---Not sure---*/
        .nk = *nk,									/*---Highest node number---*/
        .theta = &theta,  							/*---Normalized (by tper) size of all previous increments and not including present increment---*/
        .dtheta = &dtheta,						/*---Dummy variable for linear static analysis---*/
        .tper = tper,								/*---Use given step size---*/
        .nmethod = nmethod,  						/*---Flag that deifnes numerical method: 1: static linear or nonlinear, 2: frequency (linear), 3: buckling, 4: dynamic linear or non-linear, etc---*/
        .xload = xload,								/*---Concentrated load in direction of idof of node "node" (global coordinates)---*/
        .xforc = xforc,   							/*---Scalar value of the force in one direction---*/
        .xboun = xboun,								/*---Magnitude of constraint at end of a step---*/
        .ntmat_ = ntmat_,  							/*---Maximum number of temperature data points for any material property for any material---*/
        .vold = vold,								/*---Displacement of node j in direction i at the start of an iteration---*/
        .veold = veold,   							/*---Velocity of node j in direction i at the start of an iteration---*/
        .fn = fn, 									/*---values of forces read from calculix---*/
        .cocon = cocon,								/*---Conductivity coefficient k at location---*/
        .ncocon = ncocon,							/*---Number of conductivity constants---*/
        .mi = mi   									/*---Not sure---*/
    };

			printf("simulationData address      = %p\n", (void*)&simulationData);
printf("simulationData.ialset       = %p\n", (void*)simulationData.ialset);
printf("simulationData.istartset    = %p\n", (void*)simulationData.istartset);
printf("simulationData.iendset      = %p\n", (void*)simulationData.iendset);
printf("simulationData.ielmat       = %p\n", (void*)simulationData.ielmat);
printf("simulationData.kon          = %p\n", (void*)simulationData.kon);
printf("simulationData.ipkon        = %p\n", (void*)simulationData.ipkon);
printf("simulationData.lakon        = %p\n", (void*)simulationData.lakon);
printf("simulationData.co           = %p\n", (void*)simulationData.co);
printf("simulationData.nelemload    = %p\n", (void*)simulationData.nelemload);
printf("simulationData.sideload     = %p\n", (void*)simulationData.sideload);
printf("simulationData.vold         = %p\n", (void*)simulationData.vold);
fflush(stdout);



  		/* determining the global values to be used as boundary conditions
     	for a submodel */

  		/* iglob=-1 if global results are from a *FREQUENCY calculation
     	iglob=0 if no global results are used by boundary conditions
     	iglob=1 if global results are from a *STATIC calculation */

  		getglobalresults(jobnamec,&integerglob,&doubleglob,nboun,iamboun,xboun,
		   nload,sideload,iamload,&iglob,nforc,iamforc,xforc,
                   ithermal,nk,t1,iamt1,&sigma);

  		/* allocating fields for the actual external loading */

  		NNEW(xbounact,double,*nboun);
  		for(k=0;k<*nboun;++k)
		{
			xbounact[k]=xbounold[k];
		}

  		NNEW(xforcact,double,*nforc);
  		NNEW(xloadact,double,2**nload);
  		NNEW(xbodyact,double,7**nbody);

  		/* copying the rotation axis and/or acceleration vector */
  		for(k=0;k<7**nbody;k++)
		{
			xbodyact[k]=xbody[k];
		}

  		if(*ithermal==1)
		{
    		NNEW(t1act,double,*nk);
    		for(k=0;k<*nk;++k)
			{
				t1act[k]=t1old[k];
			}
  		}

  		/* assigning the body forces to the elements */

  		if(*nbody>0)
  		{	  
			printf("Assigning body force definition to elements...");
      		ifreebody=*ne+1;
      		NNEW(ipobody,ITG,2*ifreebody**nbody);

      		for(k=1;k<=*nbody;k++)
	  		{
	  			FORTRAN(bodyforce,(cbody,ibody,ipobody,nbody,set,istartset,
			     iendset,ialset,&inewton,nset,&ifreebody,&k));
	  			RENEW(ipobody,ITG,2*(*ne+ifreebody));
      		}

      		RENEW(ipobody,ITG,2*(ifreebody-1));

			printf(" done!\n");
  		}


        /*---Adapter: Create the interfaces and initialize the coupling---*/
        printf("Initializing static aeroelastic interface with %s and %s \n", preciceParticipantName, configFilename);

        Precice_Setup( configFilename, preciceParticipantName, &simulationData );

        int counter = 0;

		/* --- Main coupling loop --- */
        while (Precice_IsCouplingOngoing() )
        {
            counter = counter + 1;

            /* Adapter: adjust solver time step */
            Precice_AdjustSolverTimestep( &simulationData );

            /*---Retrieve nodal forces and apply to CCX simulation data struct (sim->xforc)---*/
            Precice_ReadCouplingData(&simulationData);

  		    /* allocating a field for the instantaneous amplitude */

  		    NNEW(ampli,double,*nam);

  		    FORTRAN(tempload,(xforcold,xforc,xforcact,iamforc,nforc,xloadold,xload,
	            xloadact,iamload,nload,ibody,xbody,nbody,xbodyold,xbodyact,
	            t1old,t1,t1act,iamt1,nk,amta,
	            namta,nam,ampli,&time,&reltime,ttime,&dtime,ithermal,nmethod,
                xbounold,xboun,xbounact,iamboun,nboun,
	            nodeboun,ndirboun,nodeforc,ndirforc,istep,&iinc,
	            co,vold,itg,&ntg,amname,ikboun,ilboun,nelemload,sideload,mi,
                ntrans,trab,inotr,veold,integerglob,doubleglob,tieset,istartset,
                iendset,ialset,ntie,nmpc,ipompc,ikmpc,ilmpc,nodempc,coefmpc,
                ipobody,iponoel,inoel,ipkon,kon,ielprop,prop,ielmat,
                shcon,nshcon,rhcon,nrhcon,cocon,ncocon,ntmat_,lakon));

  		    /* determining the internal forces and the stiffness coefficients */

  		    NNEW(f,double,*neq);

  		    /* allocating a field for the stiffness matrix */

  		    NNEW(xstiff,double,(long long)27*mi[0]**ne);

  		    /* for a *STATIC,PERTURBATION analysis with submodel boundary
     	    conditions from a *FREQUENCY analysis iperturb[0]=1 has to be
     	    temporarily set to iperturb[0]=0 in order for f to be calculated in
     	    resultsini and subsequent results* routines */

  		    if((*nmethod==1)&&(iglob<0)&&(iperturb[0]>0))
		    {
      		    iperturbsav=iperturb[0];
      		    iperturb[0]=0;
  		    }

  		    iout=-1;
  		    NNEW(v,double,mt**nk);
		    NNEW(djdrho_expl, double, *ne);
  		    NNEW(fn,double,mt**nk);
		    NNEW(brhs,double,mt**nk);
  		    //NNEW(stx,double,6*mi[0]**ne); Now passing stx as an input argument to linstatic
  		    NNEW(inum,ITG,*nk);

  		    results(co,nk,kon,ipkon,lakon,ne,v,stn,inum,stx,
	  	    elcon,nelcon,rhcon,nrhcon,alcon,nalcon,alzero,ielmat,
	  	    ielorien,norien,orab,ntmat_,t0,t1act,ithermal,
	  	    prestr,iprestr,filab,eme,emn,een,iperturb,
	  	    f,fn,nactdof,&iout,qa,vold,b,nodeboun,
	  	    ndirboun,xbounact,nboun,ipompc,
	  	    nodempc,coefmpc,labmpc,nmpc,nmethod,cam,neq,veold,accold,
	  	    &bet,&gam,&dtime,&time,ttime,plicon,nplicon,plkcon,nplkcon,
	  	    xstateini,xstiff,xstate,npmat_,epn,matname,mi,&ielas,
	  	    &icmd,ncmat_,nstate_,stiini,vini,ikboun,ilboun,ener,enern,
	  	    emeini,xstaten,eei,enerini,cocon,ncocon,set,nset,istartset,
	  	    iendset,ialset,nprint,prlab,prset,qfx,qfn,trab,inotr,ntrans,
	  	    fmpc,nelemload,nload,ikmpc,ilmpc,istep,&iinc,springarea,
	  	    &reltime,&ne0,thicke,shcon,nshcon,
	  	    sideload,xloadact,xloadold,&icfd,inomat,pslavsurf,pmastsurf,
	  	    mortar,islavact,cdn,islavnode,nslavnode,ntie,clearini,
	  	    islavsurf,ielprop,prop,energyini,energy,&kscale,iponoel,
    	    inoel,nener,orname,&network,ipobody,xbodyact,ibody,typeboun, design, penal, sigma0, eps, rhomin, pexp, brhs, djdrho_expl, Pnorm, 0);

		    // NOTE: At this point xstiff is not penalized
	
  		    SFREE(v);
		    SFREE(fn);
		    SFREE(brhs);
		    //SFREE(stx); Now free stx in main driver
		    SFREE(inum);
		    SFREE(djdrho_expl);
  		    iout=1;

  		    if((*nmethod==1)&&(iglob<0)&&(iperturb[0]>0))
		    {
      		    iperturb[0]=iperturbsav;
  		    }

  		    /* determining the system matrix and the external forces */

		    // Diagonal entries of stiffness matrix K
  		    NNEW(ad,double,*neq);
  		    NNEW(fext,double,*neq);

  		    if(*nmethod==11)
		    {

    		    /* determining the nodes and the degrees of freedom in those nodes
       		    belonging to the substructure */

      		    NNEW(iretain,ITG,*nk);
      		    NNEW(noderetain,ITG,*nk);
      		    NNEW(ndirretain,ITG,*nk);
      		    nretain=0;

      		    for(i=0;i<*nboun;i++)
	  		    {
	  			    if(strcmp1(&typeboun[i],"C")==0)
				    {
	      			    iretain[nretain]=i+1;
	      			    noderetain[nretain]=nodeboun[i];
	      			    ndirretain[nretain]=ndirboun[i];
	      			    nretain++;
	  			    }
      		    }

      		    /* nretain!=0: submatrix application
        	    nretain==0: Green function application */

      		    if(nretain>0)
	  		    {
	  			    RENEW(iretain,ITG,nretain);
	  			    RENEW(noderetain,ITG,nretain);
	  			    RENEW(ndirretain,ITG,nretain);
      		    }
	  		    else
	  		    {
	  			    SFREE(iretain);SFREE(noderetain);SFREE(ndirretain);
      		    }

      		    /* creating the right size au */


      		    NNEW(au,double,nzs[2]);
      		    rhsi=0;
			    //      nmethodl=2;
     	 	    nmethodl=*nmethod;

      		    /* providing for the mass matrix in case of Green functions */

      		    if(nretain==0)
	  		    {
	  			    mass[0]=1.;
	  			    NNEW(adb,double,*neq);
	  			    NNEW(aub,double,nzs[1]);
      		    }
  		    } // end if(imethod ==11)
		    else
		    {   	
			    /*############################################################################################*/
			    /* linear static calculation */

			    printf(" Starting linstatic calculation...\n");

			    // Off-diagonal entries of stiffness matrix K
      		    NNEW(au,double,*nzs);
      		    nmethodl=*nmethod;

      		    /* if submodel calculation with a global model obtained by
         	    a *FREQUENCY calculation: replace stiffness matrix K by
         	    K-sigma*M */

      		    if(iglob<0)
	  		    {
	  			    mass[0]=1;
	  			    NNEW(adb,double,*neq);
	  			    NNEW(aub,double,nzs[1]);
      		    }
  		    }

  		    mafillsmmain(co,nk,kon,ipkon,lakon,ne,nodeboun,ndirboun,xbounact,nboun,
	        ipompc,nodempc,coefmpc,nmpc,nodeforc,ndirforc,xforcact,
	        nforc,nelemload,sideload,xloadact,nload,xbodyact,ipobody,
	        nbody,cgr,ad,au,fext,nactdof,icol,jq,irow,neq,nzl,&nmethodl,
	        ikmpc,ilmpc,ikboun,ilboun,
	        elcon,nelcon,rhcon,nrhcon,alcon,nalcon,alzero,ielmat,
	        ielorien,norien,orab,ntmat_,
	        t0,t1act,ithermal,prestr,iprestr,vold,iperturb,sti,
	        nzs,stx,adb,aub,iexpl,plicon,nplicon,plkcon,nplkcon,
	        xstiff,npmat_,&dtime,matname,mi,
            ncmat_,mass,&stiffness,&buckling,&rhsi,&intscheme,physcon,
            shcon,nshcon,cocon,ncocon,ttime,&time,istep,&iinc,&coriolis,
	        ibody,xloadold,&reltime,veold,springarea,nstate_,
            xstateini,xstate,thicke,integerglob,doubleglob,
	        tieset,istartset,iendset,ialset,ntie,&nasym,pslavsurf,
	        pmastsurf,mortar,clearini,ielprop,prop,&ne0,fnext,&kscale,
	        iponoel,inoel,&network,ntrans,inotr,trab,design,penal, mat_dens);

  		    /* check for negative Jacobians */
  		    if(nmethodl==0) *nmethod=0;

  		    if(nasym==1)
  		    {
      		    RENEW(au,double,2*nzs[1]);
      		    symmetryflag=2;
      		    inputformat=1;

      		    FORTRAN(mafillsmas,(co,nk,kon,ipkon,lakon,ne,nodeboun,
                ndirboun,xbounact,nboun,
		  	    ipompc,nodempc,coefmpc,nmpc,nodeforc,ndirforc,xforcact,
		  	    nforc,nelemload,sideload,xloadact,nload,xbodyact,ipobody,
		  	    nbody,cgr,ad,au,fext,nactdof,icol,jq,irow,neq,nzl,
		  	    nmethod,ikmpc,ilmpc,ikboun,ilboun,
		  	    elcon,nelcon,rhcon,nrhcon,alcon,nalcon,alzero,
		  	    ielmat,ielorien,norien,orab,ntmat_,
		  	    t0,t1act,ithermal,prestr,iprestr,vold,iperturb,sti,
		  	    nzs,stx,adb,aub,iexpl,plicon,nplicon,plkcon,nplkcon,
		  	    xstiff,npmat_,&dtime,matname,mi,
                ncmat_,mass,&stiffness,&buckling,&rhsi,&intscheme,
                physcon,shcon,nshcon,cocon,ncocon,ttime,&time,istep,&iinc,
                &coriolis,ibody,xloadold,&reltime,veold,springarea,nstate_,
                xstateini,xstate,thicke,
                integerglob,doubleglob,tieset,istartset,iendset,
		  	    ialset,ntie,&nasym,pslavsurf,pmastsurf,mortar,clearini,
		  	    ielprop,prop,&ne0,&kscale,iponoel,inoel,&network));
  		    }
  		    /* determining the right hand side */

		    //printf(" Computing the Right Hand Side after mafillsmas...");
  		    NNEW(b,double,*neq);
		
		    double res_l2 = 0.0;   // ||b||_2

  		    for(k=0;k<*neq;++k)
  		    {
	  		    double r = fext[k] - f[k];
      		    b[k] = r;
  		    }
		
  		    SFREE(fext);
  		    SFREE(f);

		    if(*nmethod!=0)
	    	{
   			    /* linear static applications */
    		    if(*isolver==0)
			    {
				    #ifdef SPOOLES
				    printf("I am calling SPOOLES() \n");
      			    spooles(ad,au,adb,aub,&sigma,b,icol,irow,neq,nzs,&symmetryflag,
              	    &inputformat,&nzs[2]);
				    #else
            	    printf("*ERROR in linstatic: the SPOOLES library is not linked\n\n");
            	    FORTRAN(stop,());
				    #endif
    		    }
    		    else if((*isolver==2)||(*isolver==3))
			    {
      			    if(nasym>0)
				    {
	  				    printf(" *ERROR in nonlingeo: the iterative solver cannot be used for asymmetric matrices\n\n");
	  				    FORTRAN(stop,());
      			    }
      			    preiter(ad,&au,b,&icol,&irow,neq,nzs,isolver,iperturb);
    		    }
    		    else if(*isolver==4)
			    {
				    #ifdef SGI
      			    if(nasym>0)
				    {
	  				    printf(" *ERROR in nonlingeo: the SGI solver cannot be used for asymmetric matrices\n\n");
	  				    FORTRAN(stop,());
      			    }
      			    token=1;
      			    sgi_main(ad,au,adb,aub,&sigma,b,icol,irow,neq,nzs,token);
				    #else
            	    printf("*ERROR in linstatic: the SGI library is not linked\n\n");
            	    FORTRAN(stop,());
				    #endif
    		    }
    		    else if(*isolver==5)
			    {
				    #ifdef TAUCS
      			    if(nasym>0)
				    {
	  				    printf(" *ERROR in nonlingeo: the TAUCS solver cannot be used for asymmetric matrices\n\n");
	  				    FORTRAN(stop,());
      			    }
      			    tau(ad,&au,adb,aub,&sigma,b,icol,&irow,neq,nzs);
				    #else
            	    printf("*ERROR in linstatic: the TAUCS library is not linked\n\n");
            	    FORTRAN(stop,());
				    #endif
    		    }
    		    else if(*isolver==7)
			    {
				    #ifdef PARDISO

				    /* NOTE:
					sigma = 0 for all linear elastic calculations
					neq   = Stiffness matrix size
					nzs   = Number of non-zeros in stiffness matrix
					symmetryflag 	= 0 for linear-elastic system
					inputformat 	= 0 for all linear-elastic systems
					jq 				= not required for linear elastic systems
					nrhs            = 1 for all linear elastic systems
				    */					

				    printf("Caling PARDISO @ second pass..\n");
				    pardiso_main(ad,au,adb,aub,&sigma,b,icol,irow,neq,nzs,
		   		    &symmetryflag,&inputformat,jq,&nzs[2],&nrhs);

				    #else
            	    printf("*ERROR in linstatic: the PARDISO library is not linked\n\n");
            	    FORTRAN(stop,());
				    #endif
                } // end pardiso conditional here

                SFREE(au);
                SFREE(ad);

                if(iglob<0)
			    {
				    SFREE(adb);
			    	SFREE(aub);
			    }

				/* NOTE: 	At this point "b" holds the displacement in equation space. 
							Allocate memory for full nodal displacement vector "v"
							Pass both v and b to results()->resultsini.f to get full nodal representation
							
				*/
    			/* calculating the stresses and storing */
    			/* the results in frd format for each valid eigenmode */
    			NNEW(v,double,mt**nk);
    			NNEW(fn,double,mt**nk);
				NNEW(brhs,double,mt**nk);
    			NNEW(stn,double,6**nk);
    			NNEW(inum,ITG,*nk);
				NNEW(djdrho_expl, double, *ne);

    			if(strcmp1(&filab[261],"E   ")==0) NNEW(een,double,6**nk);
    			if(strcmp1(&filab[2697],"ME  ")==0) NNEW(emn,double,6**nk);
    			if(strcmp1(&filab[522],"ENER")==0) NNEW(enern,double,*nk);
    			if(strcmp1(&filab[2175],"CONT")==0) NNEW(cdn,double,6**nk);

    			NNEW(eei,double,6*mi[0]**ne);
    			if(*nener==1)
				{
					NNEW(stiini,double,6*mi[0]**ne);
        			NNEW(emeini,double,6*mi[0]**ne);
					NNEW(enerini,double,mi[0]**ne);
				}

				printf("\n========================================\n");
				printf("STRESS CALCULATION\n");
				printf("========================================\n");

				// Pass displacements (b) to results, compute stress, rhs adjoint and explicit terms. 
    			results(co,nk,kon,ipkon,lakon,ne,v,stn,inum,stx,
	    		    elcon,nelcon,rhcon,nrhcon,alcon,nalcon,alzero,ielmat,
	    		    ielorien,norien,orab,ntmat_,t0,t1act,ithermal,
	    		    prestr,iprestr,filab,eme,emn,een,iperturb,
            	    f,fn,nactdof,&iout,qa,vold,b,nodeboun,ndirboun,xbounact,nboun,ipompc,
	    		    nodempc,coefmpc,labmpc,nmpc,nmethod,cam,neq,veold,accold,&bet,
            	    &gam,&dtime,&time,ttime,plicon,nplicon,plkcon,nplkcon,
	    		    xstateini,xstiff,xstate,npmat_,epn,matname,mi,&ielas,&icmd,
            	    ncmat_,nstate_,stiini,vini,ikboun,ilboun,ener,enern,emeini,
            	    xstaten,eei,enerini,cocon,ncocon,set,nset,istartset,iendset,
            	    ialset,nprint,prlab,prset,qfx,qfn,trab,inotr,ntrans,fmpc,
	    		    nelemload,nload,ikmpc,ilmpc,istep,&iinc,springarea,&reltime,
            	    &ne0,thicke,shcon,nshcon,
            	    sideload,xloadact,xloadold,&icfd,inomat,pslavsurf,pmastsurf,
            	    mortar,islavact,cdn,islavnode,nslavnode,ntie,clearini,
	    		    islavsurf,ielprop,prop,energyini,energy,&kscale,iponoel,
            	    inoel,nener,orname,&network,ipobody,xbodyact,ibody,typeboun, design, penal, sigma0, eps, rhomin, pexp, brhs, djdrho_expl,Pnorm, 1);

                simulationData.fn = fn;

			    /* ------------------------------------------------------------
   				Max absolute displacement components (x,y,z) from nodal field v
   				Place this AFTER results(...) computed v, and BEFORE SFREE(v).
   				------------------------------------------------------------ */
				{
    				double umax_x = 0.0, umax_y = 0.0, umax_z = 0.0;
    				ITG node_umax_x = 0, node_umax_y = 0, node_umax_z = 0;

    				for (ITG n = 0; n < *nk; ++n) 
					{

        				/* In CCX nodal vectors are typically stored as:
           					v[n*mt + 1] = Ux, v[n*mt + 2] = Uy, v[n*mt + 3] = Uz
           					(index 0 is usually temperature/unused depending on analysis)
        				*/
        				const double ux = v[n*mt + 1];
        				const double uy = v[n*mt + 2];
        				const double uz = v[n*mt + 3];

        				const double ax = fabs(ux);
        				const double ay = fabs(uy);
        				const double az = fabs(uz);

        				if (ax > umax_x) { umax_x = ax; node_umax_x = n + 1; } /* +1 => CCX node id style */
        				if (ay > umax_y) { umax_y = ay; node_umax_y = n + 1; }
        				if (az > umax_z) { umax_z = az; node_umax_z = n + 1; }
    				}

    				printf("\n========================================\n");
    				printf("MAX |DISPLACEMENT| (nodal)\n");
    				printf("========================================\n");
    				printf("Max |Ux| = %.15e  at node %d\n", umax_x, (int)node_umax_x);
    				printf("Max |Uy| = %.15e  at node %d\n", umax_y, (int)node_umax_y);
    				printf("Max |Uz| = %.15e  at node %d\n", umax_z, (int)node_umax_z);
    				printf("========================================\n\n");
				}

                SFREE(eei);
    		    if(*nener==1)
			    {
				    SFREE(stiini);
				    SFREE(emeini);
			    	SFREE(enerini);
			    }
                    
                /*---Copy current v into vold---*/
                memcpy(&vold[0],&v[0],sizeof(double)*mt**nk);

                /*---Save the current displacement state (vold) for implicit calculations---*/
                if(Precice_IsWriteCheckpointRequired())
                {
                    Precice_WriteIterationCheckpoint( &simulationData, vold );
        		    Precice_FulfilledWriteCheckpoint();
                }

                /*---Transmit the interface discplacement state---*/ 
                Precice_WriteCouplingData(&simulationData);

                /*---Advance the coupling state---*/
			    Precice_Advance(&simulationData);

		        /*---For implicit calculations, load the previous displacement state---*/
			
			    if(Precice_IsReadCheckpointRequired())
			    {
    			    Precice_ReadIterationCheckpoint(&simulationData, vold );
        		    Precice_FulfilledReadCheckpoint();
    		    }
    			    
   	 			memcpy(&sti[0],&stx[0],sizeof(double)*6*mi[0]*ne0);

    			++*kode;
            } // if nmethod!=0 ends 

    		/* for cyclic symmetric sectors: duplicating the results */
    		if(*mcs>0)
			{
				ptime=*ttime+time;
    		}
    		else
			{
				if(strcmp1(&filab[1044],"ZZS")==0)
				{
	    			NNEW(neigh,ITG,40**ne);
	    			NNEW(ipneigh,ITG,*nk);
				}
				ptime=*ttime+time;

				if(strcmp1(&filab[1044],"ZZS")==0)
				{
				    SFREE(ipneigh);
					SFREE(neigh);
				}
    		}   
            
            SFREE(v);
		    SFREE(stn);
			SFREE(inum);
    		SFREE(b);
			SFREE(fn);

    		if(strcmp1(&filab[261],"E   ")==0) SFREE(een);
    		if(strcmp1(&filab[2697],"ME  ")==0) SFREE(emn);
    		if(strcmp1(&filab[522],"ENER")==0) SFREE(enern);
    	    if(strcmp1(&filab[2175],"CONT")==0) SFREE(cdn);
        } // MDO implicit loop ends here
         
        updateCO(coUpdated, vold, *nk, mt);

  		/* updating the loading at the end of the step;
     			important in case the amplitude at the end of the step
     			is not equal to one */
  		for(k=0;k<*nboun;++k){xbounold[k]=xbounact[k];}
  		for(k=0;k<*nforc;++k){xforcold[k]=xforcact[k];}
  		for(k=0;k<2**nload;++k){xloadold[k]=xloadact[k];}
  		for(k=0;k<7**nbody;k=k+7){xbodyold[k]=xbodyact[k];}

  		if(*ithermal==1)
		{
    		for(k=0;k<*nk;++k){t1old[k]=t1act[k];}
    		for(k=0;k<*nk;++k){vold[mt*k]=t1act[k];}
  		}

  		SFREE(xbounact);
		SFREE(xforcact);
		SFREE(xloadact);
		SFREE(t1act);
		SFREE(ampli);
  		SFREE(xbodyact);
		if(*nbody>0) SFREE(ipobody);
		SFREE(xstiff);

  		if(iglob!=0)
		{
			SFREE(integerglob);
			SFREE(doubleglob);
		}

  		*irowp=irow;*enerp=ener;*xstatep=xstate;*ipkonp=ipkon;*lakonp=lakon;
  		*konp=kon;*ielmatp=ielmat;*ielorienp=ielorien;*icolp=icol;
  		(*ttime)+=(*tper);

        /* Adapter: Free the memory */
  	    Precice_FreeData( &simulationData );

        SFREE(coUpdated);
  		return;
	}
	