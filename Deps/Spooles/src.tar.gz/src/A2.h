#ifndef _A2_
#define _A2_
#include "A2/A2.h"
#endif
